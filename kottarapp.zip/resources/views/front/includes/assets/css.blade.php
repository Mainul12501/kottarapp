<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700&amp;display=swap&amp;subset=latin-ext" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('/') }}frontend/assets/css/all.min.css">
<link href="{{ asset('/') }}frontend/assets/css/aos.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('/') }}frontend/assets/css/bootstrap.min.css">
<link href="{{ asset('/') }}frontend/assets/css/select2.min.css" rel="stylesheet" />
{{--<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />--}}
<link href="{{ asset('/') }}frontend/assets/css/owl.carousel.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css" />
<link rel="stylesheet" href="{{ asset('/') }}frontend/assets/css/style.css">
<link rel="stylesheet" href="{{ asset('/') }}backend/assets/css/helper.min.css">
<link rel="stylesheet" href="{{ asset('/') }}backend/assets/css/vendor/toastrjs.min.css">
<link rel="stylesheet" href="{{ asset('/') }}frontend/assets/css/color-1.css">
@yield('style')

