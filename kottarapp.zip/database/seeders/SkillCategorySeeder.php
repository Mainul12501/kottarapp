<?php

namespace Database\Seeders;

use App\Models\Admin\SkillCategory;
use Illuminate\Database\Seeder;

class SkillCategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        SkillCategory::factory()
            ->count(5)
            ->create();
    }
}
