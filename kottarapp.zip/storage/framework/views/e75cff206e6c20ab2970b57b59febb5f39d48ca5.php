<div>
    
    <table id="dataTable" class="table table-striped dt-responsive table-responsive nowrap w-100">
        <thead>
        <tr>
            <th>#</th>
            <th>Skill Category</th>
            <th>Skill Sub Category</th>
            <th>Title</th>
            <th>Description</th>
            <th>Budget</th>
            <th>Required Skills</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>

                <td>
                    <?php echo e($job->skillCategory->category_name); ?>

                </td>
                <td><?php echo e($job->skillSubCategory->sub_category_name); ?></td>
                <td><?php echo e($job->project_title); ?></td>
                <td><?php echo $job->project_description; ?></td>
                <td>$<?php echo e($job->budget); ?></td>
                <td><?php $__currentLoopData = $job->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($skill->skill_name); ?><?php if((count($job->skills)-1) != $key): ?>, <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td wire:ignore>




                    <select class="form-control" wire:model="job_status" wire:change="changeStatus(<?php echo e($job->id); ?>,$event.target.value)" id="">
                        <option value="0" <?php echo e($job->status == 0 ? 'selected' : ''); ?>>Pending</option>
                        <option value="1" <?php echo e($job->status == 1 ? 'selected' : ''); ?>>Approved</option>
                        <option value="2" <?php echo e($job->status == 2 ? 'selected' : ''); ?>>Completed</option>
                        <option value="3" <?php echo e($job->status == 3 ? 'selected' : ''); ?>>Rejected</option>
                    </select>
                </td>
                <td>
                    <a href="" class="btn btn-primary btn-sm mt-1 py-0 px-1" title="View">
                        <i class="dripicons-preview"></i>
                    </a>
                    <a href="<?php echo e(route('approve-job', ['id' => $job->id])); ?>" class="btn btn-primary btn-sm mt-1 py-0 px-1" title="Approve">
                        <i class="dripicons-arrow-thin-up f-s-11"></i>
                    </a>
                    <form action="" method="post" style="display: inline-block" onsubmit="return confirm('Are you sure to delete this Admin?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button type="submit" class="btn btn-danger btn-sm mt-1 py-0 px-1">
                            <i class="dripicons-trash f-s-11"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if(session()->has('message')): ?>
        <script>
            toastr.success("<?php echo e(session()->get('message')); ?>");
        </script>
    <?php endif; ?>
</div>
<?php /**PATH G:\wamp64\www\kottarapp\resources\views/livewire/admin/job-approve.blade.php ENDPATH**/ ?>