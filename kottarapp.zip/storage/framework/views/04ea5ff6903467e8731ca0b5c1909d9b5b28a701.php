<?php $__env->startSection('title'); ?>
    Update Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-sm-12">
        <div class="jm_headings">
            <h5>Update My Profile</h5>
            <a class="btn btn-primary mypbtn" href="#"> <?php echo e($user->user_role_type == 1 ? 'SME' : ''); ?> <?php echo e($user->user_role_type == 0 ? 'Student' : ''); ?> profile</a>
        </div>
        <div class="section-divider">
        </div>
        <form action="<?php echo e(route('update-profile')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(auth()->user()->user_role_type == 2): ?>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >First Name</label>
                                <input type="text" class="form-control" name="first_name" placeholder="Enter your first name" value="<?php echo e($user->userDetails->first_name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Last Name</label>
                                <input type="text" class="form-control" name="last_name" placeholder="Enter your last name" value="<?php echo e($user->userDetails->last_name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Enter your company official email" value="<?php echo e($user->email); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Phone</label>
                                <input type="text" name="phone" class="form-control" placeholder="Enter your phone number" value="<?php echo e($user->userDetails->phone); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label>Profile Image</label>
                                <input type="file" name="profile_image" class="form-control" accept="image/*">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Company name</label>
                                <input type="text" class="form-control" placeholder="Enter your company name" name="company_name" value="<?php echo e($user->userDetails->company_name); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Location</label>
                                <select name="country" class="form-control select2" data-placeholder="Select a country">
                                    <option></option>
                                    <option value="United Arab Emirates" selected>UNITED ARAB EMIRATES</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Emirate State Name</label>
                                <select name="emirate_state_name" id="" class="form-control select2" data-placeholder="Select a state Name">
                                    <option></option>
                                    <option value="Abu Dhabi" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Abu Dhabi' ? 'selected' : ''); ?>>Abu Dhabi</option>
                                    <option value="Dubai" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Dubai' ? 'selected' : ''); ?>>Dubai</option>
                                    <option value="Sharjah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Sharjah' ? 'selected' : ''); ?>>Sharjah</option>
                                    <option value="Ajman" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Ajman' ? 'selected' : ''); ?>>Ajman</option>
                                    <option value="Fujairah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Fujairah' ? 'selected' : ''); ?>>Fujairah</option>
                                    <option value="Ras Al-Khaimah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Ras Al-Khaimah' ? 'selected' : ''); ?>>Ras Al-Khaimah</option>
                                    <option value="Umm al Quwain" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Umm al Quwain' ? 'selected' : ''); ?>>Umm al Quwain</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Established Year</label>
                                <input type="text" class="form-control" name="company_establish_year" placeholder="Enter Company Established Year" value="<?php echo e($user->userDetails->company_establish_year); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Are you</label>
                                <select class="form-control select2" name="company_status" data-placeholder="Select an option">
                                    <option value="Start-up, Young company" <?php echo e($user->userDetails->company_status == 'Start-up, Young company' ? 'selected' : ''); ?>>Start-up, Young company</option>
                                    <option value="Enterprise, Government" <?php echo e($user->userDetails->company_status == 'Enterprise, Government' ? 'selected' : ''); ?>>Enterprise, Government</option>
                                    <option value="Entity, Private Entity, Others" <?php echo e($user->userDetails->company_status == 'Entity, Private Entity, Others' ? 'selected' : ''); ?>>Entity, Private Entity, Others</option>
                                    <option value="Other" <?php echo e($user->userDetails->company_status == 'Other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Business Name</label>
                                <input type="text" class="form-control" name="business_name" placeholder="Enter business name" value="<?php echo e($user->userDetails->business_name); ?>">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Company Size</label>
                                <select class="form-control select2" name="company_size" data-placeholder="Select company size">
                                    <option value="01-10 Person" <?php echo e($user->userDetails->company_size == '01-10 Person' ? 'selected' : ''); ?>>01-10 Person</option>
                                    <option value="15-50 Person" <?php echo e($user->userDetails->company_size == '15-50 Person' ? 'selected' : ''); ?>>15-50 Person</option>
                                    <option value="51-100 Person" <?php echo e($user->userDetails->company_size == '51-100 Person' ? 'selected' : ''); ?>>51-100 Person</option>
                                    <option value="501-1000 Person or more" <?php echo e($user->userDetails->company_size == '501-1000 Person or more' ? 'selected' : ''); ?>>501-1000 Person or more</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Sector Speciality</label>
                                <select class="form-control select2" name="company_speciality" data-placeholder="Select company speciality">
                                    <option value="Event Management" <?php echo e($user->userDetails->company_size == 'Event Management' ? 'selected' : ''); ?>>Event Management</option>
                                    <option value="Hospitals" <?php echo e($user->userDetails->company_size == 'Hospitals' ? 'selected' : ''); ?>>Hospitals</option>
                                    <option value="Ecommerce industry" <?php echo e($user->userDetails->company_size == 'Ecommerce industry' ? 'selected' : ''); ?>>Ecommerce industry</option>
                                    <option value="Food industry" <?php echo e($user->userDetails->company_size == 'Food industry' ? 'selected' : ''); ?>>Food industry</option>
                                    <option value="Automobiles industry" <?php echo e($user->userDetails->company_size == 'Automobiles industry' ? 'selected' : ''); ?>>Automobiles industry</option>
                                    <option value="Power industry" <?php echo e($user->userDetails->company_size == 'Power industry' ? 'selected' : ''); ?>>Power industry</option>
                                    <option value="Garment and textiles" <?php echo e($user->userDetails->company_size == 'Garment and textiles' ? 'selected' : ''); ?>>Garment and textiles</option>
                                    <option value="Financial institution" <?php echo e($user->userDetails->company_size == 'Financial institution' ? 'selected' : ''); ?>>Financial institution</option>
                                    <option value="Agribusiness" <?php echo e($user->userDetails->company_size == 'Agribusiness' ? 'selected' : ''); ?>>Agribusiness</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Select Services</label>
                                <select class="form-control select2" name="company_service" data-placeholder="Select company Service">
                                    <option value="Event Management" <?php echo e($user->userDetails->company_size == 'Event Management' ? 'selected' : ''); ?>>Event Management</option>
                                    <option value="Hospitals" <?php echo e($user->userDetails->company_size == 'Hospitals' ? 'selected' : ''); ?>>Hospitals</option>
                                    <option value="Ecommerce industry" <?php echo e($user->userDetails->company_size == 'Ecommerce industry' ? 'selected' : ''); ?>>Ecommerce industry</option>
                                    <option value="Food industry" <?php echo e($user->userDetails->company_size == 'Food industry' ? 'selected' : ''); ?>>Food industry</option>
                                    <option value="Automobiles industry" <?php echo e($user->userDetails->company_size == 'Automobiles industry' ? 'selected' : ''); ?>>Automobiles industry</option>
                                    <option value="Power industry" <?php echo e($user->userDetails->company_size == 'Power industry' ? 'selected' : ''); ?>>Power industry</option>
                                    <option value="Garment and textiles" <?php echo e($user->userDetails->company_size == 'Garment and textiles' ? 'selected' : ''); ?>>Garment and textiles</option>
                                    <option value="Financial institution" <?php echo e($user->userDetails->company_size == 'Financial institution' ? 'selected' : ''); ?>>Financial institution</option>
                                    <option value="Agribusiness" <?php echo e($user->userDetails->company_size == 'Agribusiness' ? 'selected' : ''); ?>>Agribusiness</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Trade license Number</label>
                                <input type="text" name="trade_license_no" value="<?php echo e($user->userDetails->trade_license_no); ?>" class="form-control" placeholder="Trade license Number" />
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label  >Trade license File</label>
                                <input type="file" name="user_document_files[]" multiple class="form-control" />
                                <?php if(!empty($user)): ?>

                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>
            <?php elseif(auth()->user()->user_role_type == 1): ?>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >First Name</label>
                                <input type="text" class="form-control" name="first_name" placeholder="Enter your first name" value="<?php echo e($user->userDetails->first_name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Last Name</label>
                                <input type="text" class="form-control" name="last_name" placeholder="Enter your last name" value="<?php echo e($user->userDetails->last_name); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Enter your company official email" value="<?php echo e($user->email); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Phone</label>
                                <input type="text" name="phone" class="form-control" placeholder="Enter your phone number" value="<?php echo e($user->userDetails->phone); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label>Profile Image</label>
                                <input type="file" name="profile_image" class="form-control" accept="image/*">
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Date of Birth</label>
                                <input type="text" class="form-control" name="dob" id="datepicker" value="<?php echo e(!empty($user->userDetails->userDetails->dob) ? $user->userDetails->userDetails->dob->format('m/d/Y') : date('m/d/Y')); ?>" />
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Gender</label>
                                <select name="gender" class="form-control select2" data-placeholder="Select your gender">
                                    <option></option>
                                    <option value="male" <?php echo e($user->userDetails->gender == 'male' ? "selected" : ''); ?>>Male</option>
                                    <option value="female" <?php echo e($user->userDetails->gender == 'female' ? "selected" : ''); ?>>Female</option>
                                    <option value="other" <?php echo e($user->userDetails->gender == 'other' ? "selected" : ''); ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Skills</label>
                                <select name="skills[]" multiple class="form-control select2" data-placeholder="Select your skills">
                                    <option></option>
                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skill->id); ?>" <?php if(!empty($user->skills)): ?> <?php $__currentLoopData = $user->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($userSkill->id == $skill->id): ?> selected <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>><?php echo e($skill->skill_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Location</label>
                                <select name="country" class="form-control select2" data-placeholder="Select a country">
                                    <option></option>
                                    <option value="United Arab Emirates" selected>UNITED ARAB EMIRATES</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Emirate State Name</label>
                                <select name="emirate_state_name" id="" class="form-control select2" data-placeholder="Select a state Name">
                                    <option></option>
                                    <option value="Abu Dhabi" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Abu Dhabi' ? 'selected' : ''); ?>>Abu Dhabi</option>
                                    <option value="Dubai" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Dubai' ? 'selected' : ''); ?>>Dubai</option>
                                    <option value="Sharjah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Sharjah' ? 'selected' : ''); ?>>Sharjah</option>
                                    <option value="Ajman" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Ajman' ? 'selected' : ''); ?>>Ajman</option>
                                    <option value="Fujairah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Fujairah' ? 'selected' : ''); ?>>Fujairah</option>
                                    <option value="Ras Al-Khaimah" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Ras Al-Khaimah' ? 'selected' : ''); ?>>Ras Al-Khaimah</option>
                                    <option value="Umm al Quwain" <?php echo e(!empty($user->userDetails->emirate_state_name) && $user->userDetails->emirate_state_name == 'Umm al Quwain' ? 'selected' : ''); ?>>Umm al Quwain</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Are you</label>
                                <select class="form-control select2" name="company_status" data-placeholder="Select an option">
                                    <option value="High School Graduate" <?php echo e($user->userDetails->company_status == 'High School Graduate' ? 'selected' : ''); ?>>High School Graduate</option>
                                    <option value="University Student" <?php echo e($user->userDetails->company_status == 'University Student' ? 'selected' : ''); ?>>University Student</option>
                                    <option value="Fresh Graduate" <?php echo e($user->userDetails->company_status == 'Fresh Graduate' ? 'selected' : ''); ?>>Fresh Graduate</option>
                                    <option value="Other" <?php echo e($user->userDetails->company_status == 'Other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >University or School</label>
                                <select class="form-control select2" name="university_name" data-placeholder="Select University or School">
                                    <option value="Zayed University - Abu Dhabi" <?php echo e($user->userDetails->university_name == 'Zayed University - Abu Dhabi' ? 'selected' : ''); ?>>Zayed University - Abu Dhabi</option>
                                    <option value="Zayed University - Dubai" <?php echo e($user->userDetails->university_name == 'Zayed University - Dubai' ? 'selected' : ''); ?>>Zayed University - Dubai</option>
                                    <option value="Khalifa University of Science and Technology" <?php echo e($user->userDetails->university_name == 'Khalifa University of Science and Technology' ? 'selected' : ''); ?>>Khalifa University of Science and Technology</option>
                                    <option value="Abu Dhabi University" <?php echo e($user->userDetails->university_name == 'Abu Dhabi University' ? 'selected' : ''); ?>>Abu Dhabi University</option>
                                    <option value="United Arab Emirates University" <?php echo e($user->userDetails->university_name == 'United Arab Emirates University' ? 'selected' : ''); ?>>United Arab Emirates University</option>
                                    <option value="Fatima College Of Health Sciences" <?php echo e($user->userDetails->university_name == 'Fatima College Of Health Sciences' ? 'selected' : ''); ?>>Fatima College Of Health Sciences</option>
                                    <option value="NYU Abu Dhabi" <?php echo e($user->userDetails->university_name == 'NYU Abu Dhabi' ? 'selected' : ''); ?>>NYU Abu Dhabi</option>
                                    <option value="Higher Colleges of Technology" <?php echo e($user->userDetails->university_name == 'Higher Colleges of Technology' ? 'selected' : ''); ?>>Higher Colleges of Technology</option>
                                    <option value="Sorbonne University, Abu Dhabi" <?php echo e($user->userDetails->university_name == 'Sorbonne University, Abu Dhabi' ? 'selected' : ''); ?>>Sorbonne University, Abu Dhabi</option>
                                    <option value="United Arab Emirates University" <?php echo e($user->userDetails->university_name == 'United Arab Emirates University' ? 'selected' : ''); ?>>United Arab Emirates University</option>
                                    <option value="Ajman University" <?php echo e($user->userDetails->university_name == 'Ajman University' ? 'selected' : ''); ?>>Ajman University</option>
                                    <option value="American University of Sharjah" <?php echo e($user->userDetails->university_name == 'American University of Sharjah' ? 'selected' : ''); ?>>American University of Sharjah</option>
                                    <option value="Other" <?php echo e($user->userDetails->university_name == 'Other' ? 'selected' : ''); ?>>Other</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Emirates ID No.</label>
                                <input type="text" name="emirates_id_no" class="form-control" value="<?php echo e($user->userDetails->emirates_id_no); ?>" placeholder="Emirate ID Number" />
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Upload Emirates ID</label>
                                <input type="file" name="user_document_files[]" multiple class="form-control" />
                            </div>
                        </div>

                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label  >About Student</label>
                                <textarea class="form-control" name="description"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="form-group row">
                <div  class="col-md-8 mx-auto text-center">
                    <button type="submit" class="btn btn-primary"><?php echo e(auth()->user()->submit_status == 0 ? 'Submit Profile' : 'Update'); ?></button>
                </div>
            </div>

        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $( function() {
            $( "#datepicker" ).datepicker();
        } );
    </script>
    <script>
        CKEDITOR.replace( 'description' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.auth-front.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/auth-front/profile/profile-details.blade.php ENDPATH**/ ?>