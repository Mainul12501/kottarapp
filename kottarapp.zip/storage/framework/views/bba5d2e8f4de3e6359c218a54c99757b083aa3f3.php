

<?php $__env->startSection('title'); ?>
    <?php echo e(isset($backendSetting) ? $backendSetting->site_title : ''); ?> - <?php echo e(isset($permission) ? "Update" : 'Create'); ?> Permission
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Permission', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row">
                    <div class="col-md-8 mx-auto">
                        <div class="card mt-3">
                            <div class="card-header">
                                <h4 class="float-start"><?php echo e(isset($permission) ? "Update" : 'Create'); ?> Permission</h4>
                                <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-success float-end">
                                    Manage

                                </a>
                            </div>
                            <div class="card-body">
                                <div>
                                    <form action="<?php echo e(isset($permission) ? route('permissions.update', $permission->id) : route('permissions.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php if(isset($permission)): ?>
                                            <?php echo method_field('put'); ?>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label class="form-label">Permission Title</label>
                                            <input type="text" class="form-control" name="title" value="<?php echo e(isset($permission) ? $permission->title : ''); ?>" data-provide="typeahead" id="the-basics" placeholder="Permission Title">
                                        </div>
                                        <div class="mb-3 float-end">
                                            <input type="submit" class="btn btn-success" data-provide="typeahead" id="" value="<?php echo e(isset($permission) ? 'Update' : 'Create'); ?> Permission">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/user-role-permission-management/permission/add.blade.php ENDPATH**/ ?>