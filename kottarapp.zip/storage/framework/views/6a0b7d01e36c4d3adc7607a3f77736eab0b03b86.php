

<?php $__env->startSection('title'); ?>
     Job Questions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Job Questions', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-capitalize float-start"> Job Questions</h4>
                    <a href="<?php echo e(route('job-questions.index')); ?>" class="btn btn-success float-end">
                        Manage
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($question) ? route('job-questions.update', $question->id) : route('job-questions.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($question)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Question
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Write Job Question Here." data-bs-placement="right"></i>
                            </label>
                            <input type="text" class="form-control mb-1" name="question" value="<?php echo e(isset($question) ? $question->question : ''); ?>" placeholder="Full Question" >
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('question')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Status
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Select publication status here." data-bs-placement="right"></i>
                            </label>
                            <div class="d-inline mt-3">
                                <input type="checkbox" name="status" id="switch1" <?php echo e((isset($question)&& $question->status == 0) ? '' : 'checked'); ?> data-switch="bool"/>
                                <label for="switch1" data-on-label="On" data-off-label="Off"></label>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('status')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-grid">
                            <input type="submit" class="col-6 mx-auto btn btn-success" value="<?php echo e(isset($question) ? 'Update' : 'Create'); ?> Job Question">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/backend/job-post/job-post-questions/create.blade.php ENDPATH**/ ?>