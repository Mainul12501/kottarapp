<?php $__env->startSection('title'); ?>
     Skills Sub Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Skill Sub Category', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-capitalize float-start"> Skill Sub Category</h4>
                    <a href="<?php echo e(route('skills-sub-category.index')); ?>" class="btn btn-success float-end">
                        Manage
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($skillSubCategory) ? route('skills-sub-category.update', $skillSubCategory->id) : route('skills-sub-category.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($skillSubCategory)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Category Name
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Select skill category name here" data-bs-placement="right"></i>
                            </label>
                            <select name="skill_category_id" class="form-control select2" data-toggle="select2" id="" data-placeholder="Select a Skill category">
                                <option value=""></option>
                                <?php $__currentLoopData = $skillCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skillCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($skillCategory->id); ?>" <?php echo e(isset($skillSubCategory) && $skillSubCategory->skill_category_id == $skillCategory->id ? 'selected' : ''); ?>><?php echo e($skillCategory->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['skill_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('skill_category_id')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Sub Category Name
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Write skill sub category name here" data-bs-placement="right"></i>
                            </label>
                            <input type="text" class="form-control mb-1" name="sub_category_name" value="<?php echo e(isset($skillSubCategory) ? $skillSubCategory->sub_category_name : ''); ?>" placeholder="Skill Sub Category Name" >
                            <?php $__errorArgs = ['sub_category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('sub_category_name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Publication Status
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Set Publication Status" data-bs-placement="right"></i>
                            </label>
                            <div class="d-inline mt-3">
                                <input type="checkbox" name="status" id="switch1" <?php echo e(isset($skillSubCategory) && $skillSubCategory->status == 0 ? '' : 'checked'); ?> data-switch="bool"/>
                                <label for="switch1" data-on-label="On" data-off-label="Off"></label>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('status')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-grid">
                            <input type="submit" class="col-6 mx-auto btn btn-success" value="<?php echo e(isset($skillSubCategory) ? 'Update' : 'Create'); ?> Skill Sub Category">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/backend/job-post/skill-sub-category/create.blade.php ENDPATH**/ ?>