<?php $__env->startSection('title'); ?>
    post jobs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row job_section">
        <div class="col-sm-12">
            <div class="jm_headings">
                <h5>Post a Gig</h5>
                <a class="btn btn-primary mypbtn" href="#">Company profile</a>
            </div>
            <div class="section-divider">
            </div>
            <form action="<?php echo e(isset($jobPost) ? route('client.job-post.update', $jobPost->id) : route('client.job-post.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($jobPost)): ?>
                    <?php echo method_field('put'); ?>
                <?php endif; ?>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  for="jobCategory">Job Categroy</label>
                                <select name="skill_category_id" class="form-control select2" required data-toggle="select2" data-placeholeder="Select a Job Category" id="jobCategory">
                                    <option <?php echo e(!isset($jobPost) ? 'selected' : ''); ?> disabled>Select a Job Category</option>
                                    <?php $__currentLoopData = $skillCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skillCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skillCategory->id); ?>" <?php echo e(isset($jobPost) && $jobPost->skill_category_id == $skillCategory->id ? 'selected' : ''); ?>><?php echo e($skillCategory->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  for="jobCategory">Job Sub Categroy</label>
                                <select name="skill_sub_category_id" class="form-control select2" required data-toggle="select2" data-placeholeder="Select a Job Category" id="jobSubCategory">
                                    <option <?php echo e(!isset($jobPost) ? 'selected' : ''); ?> disabled>Select a Job Category</option>
                                    <?php if(isset($jobPost)): ?>
                                        <option value="<?php echo e($jobPost->skillSubCategory->sub_category_name); ?>"></option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label >Job Title</label>
                                <input type="text" name="project_title" value="<?php echo e(isset($jobPost) ? $jobPost->project_title : ''); ?>" class="form-control" placeholder="Write Job Title Here" />
                            </div>
                        </div>

                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Required Skills</label>
                                <select name="required_skills[]" class="form-control select2" multiple="multiple" data-toggle="select2" data-placeholeder="Select required skills" id="">
                                    <option  disabled>Select required skills</option>
                                    
                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skill->id); ?>"
                                                <?php if(isset($jobPost) && !empty($jobPost->skills)): ?>
                                                    <?php $__currentLoopData = $jobPost->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedSkill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($selectedSkill->id == $skill->id): ?>
                                                            selected
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>><?php echo e($skill->skill_name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Minimum Exiperience Level</label>
                                <select name="experience_level" class="form-control select2" required id="">
                                    <option value="0" <?php echo e(isset($jobPost) && $jobPost->experience_level == 0 ? 'selected' : ''); ?>>Excited</option>
                                    <option value="1" <?php echo e(isset($jobPost) && $jobPost->experience_level == 1 ? 'selected' : ''); ?>>Eager</option>
                                    <option value="2" <?php echo e(isset($jobPost) && $jobPost->experience_level == 2 ? 'selected' : ''); ?>>Experienced</option>
                                    <option value="3" <?php echo e(isset($jobPost) && $jobPost->experience_level == 3 ? 'selected' : ''); ?>>Expert</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group ">
                                <label  >Project Description</label>
                                <textarea class="form-control" name="project_description" id="editor"><?php echo isset($jobPost) && $jobPost->project_description; ?></textarea>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Project Payment Type</label>
                                <select name="budget_type" class="form-control select2" data-toggle="select2">
                                    <option value="0" <?php echo e(isset($jobPost) && $jobPost->experience_level == 0 ? 'selected' : ''); ?>>Fixed</option>
                                    <option value="1" <?php echo e(isset($jobPost) && $jobPost->experience_level == 1 ? 'selected' : ''); ?>>Per Hour</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Budget</label>
                                <input type="number" name="budget" value="<?php echo e(isset($jobPost) && $jobPost->budget); ?>" class="form-control" />
                            </div>
                        </div>




























































                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Want to ask a question?</label>
                                <select name="job_questions[]" multiple class="form-control select2" id="">
                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($question->id); ?>"
                                                <?php if(isset($jobPost) && !empty($jobPost->jobPostQuestions)): ?>
                                                    <?php $__currentLoopData = $jobPost->jobPostQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($selectedQuestion->id == $question->id): ?>
                                                            selected
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>><?php echo e($question->question); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Upload Files</label>
                                <input type="file" name="files[]" multiple />
                                <?php if(isset($jobPost) && !empty($jobPost->jobPostFiles)): ?>
                                    <ul class="nav">
                                        <?php $__currentLoopData = $jobPost->jobPostFiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(asset($file->file_url)); ?>" download="" class="nav-link">file-<?php echo e($loop->iteeration); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>


























                <div class="form-group row">
                    <div  class="col-md-9 ">
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($jobPost) ? 'Update' : 'Create'); ?> Gig</button>
                    </div>
                </div>

            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .on-site-columns {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on('change', '#jobCategory', function () {
            getSubCategoryByCategory();
        })

        function getSubCategoryByCategory() {
            var categoryId = $('#jobCategory').val();
            $.ajax({
                url: baseUrl+'get-skill-sub-categories/'+categoryId,
                method: "GET",
                dataType: "JSON",
                success: function (data) {
                    console.log(data);
                    var option = '';
                    $.each(data, function (key, item) {
                        option += '<option value="'+item.id+'">'+item.sub_category_name+'</option>';
                    })
                    $('#jobSubCategory').empty().append(option);
                },
                error: function (error)
                {
                    toastr.error('Someting went wrong. please try again.');
                }
            })
        }
    </script>

    <?php if(isset($jobPost)): ?>
        <script>
            $(function () {
                setTimeout(function () {
                    getSubCategoryByCategory();
                }, 1000)
            })
        </script>
    <?php endif; ?>

    <script>
        CKEDITOR.replace( 'project_description' );
    </script>

    <script>
        $(document).on('change', '#freelancerWorkType', function () {
            var selectedWorkType = $(this).val();
            if(selectedWorkType == 1)
            {
                $('#freelancerLocationCountry').removeClass('d-none');
            } else {
                $('#freelancerLocationCountry').addClass('d-none');
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.auth-front.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/auth-front/client/post-job/create.blade.php ENDPATH**/ ?>