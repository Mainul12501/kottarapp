<?php $__env->startSection('title'); ?>
    Create Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Users', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row">
                    <div class="col-md-8 mx-auto">
                        <div class="card mt-3">
                            <div class="card-header">
                                <h4 class="float-start">Create User</h4>
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-success float-end">
                                    Manage

                                </a>
                            </div>
                            <div class="card-body">
                                <div>
                                    <form action="<?php echo e(isset($user) ? route('users.update', $user->id) : route('users.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php if(isset($user)): ?>
                                            <?php echo method_field('put'); ?>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label class="form-label">Name <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="name" required value="<?php echo e(isset($user) ? $user->name : ''); ?>" data-provide="typeahead" id="the-basics" placeholder="User Name">
                                            <span class="text-danger"><?php echo e($errors->has('name') ? $errors->first('name') : ''); ?></span>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Email <span class="text-danger">*</span></label>
                                            <input type="email" class="form-control" required name="email" value="<?php echo e(isset($user) ? $user->email : ''); ?>" data-provide="typeahead" id="" placeholder="User Email">
                                            <span class="text-danger"><?php echo e($errors->has('email') ? $errors->first('email') : ''); ?></span>
                                        </div>
                                        <?php if(!isset($user)): ?>
                                            <div class="mb-3">
                                                <label class="form-label"> Password <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="password" value="" data-provide="typeahead" id="" placeholder="<?php echo e(isset($user) ? 'Update' : 'User'); ?> Password <?php echo e(isset($user) ? 'if required' : ''); ?>">
                                            </div>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label class="form-label">Roles <span class="text-danger">*</span></label>
                                            <select name="roles[]" required class="select2 form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Set Roles">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role->id); ?>" <?php echo e(isset($user) && $user->roles->contains($role->id) ? 'selected' : ''); ?>><?php echo e($role->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-3 float-end">
                                            <input type="submit" class="btn btn-success" data-provide="typeahead" id="" value="<?php echo e(isset($user) ? 'Update' : 'Create'); ?> User">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/backend/user-role-permission-management/user/form.blade.php ENDPATH**/ ?>