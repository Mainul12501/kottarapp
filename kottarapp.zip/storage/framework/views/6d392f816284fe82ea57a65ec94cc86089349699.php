<?php $__env->startSection('title'); ?>
    manage jobs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row job_section">
        <div class="col-sm-12">
            <div class="jm_headings">
                <h6>Your listings are shown in the table below.</h6>
            </div>
            <div class="table-cont ">

                <table class="table table-responsive display" id="datatable-buttons">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Code</th>
                        <th>Exp. Lv</th>
                        <th>Total Budget</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $jobPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($jobPost->project_title); ?></td>
                                <td><?php echo e($jobPost->job_unique_code); ?></td>
                                <td><?php echo e($jobPost->experience_level); ?></td>
                                <td>$<?php echo e($jobPost->budget); ?></td>
                                <td><?php echo substr_replace($jobPost->project_description, '', 200); ?></td>
                                <td>
                                    <?php echo e($jobPost->status == 0 ? 'Pending' : ''); ?>

                                    <?php echo e($jobPost->status == 1 ? 'Approved' : ''); ?>

                                    <?php echo e($jobPost->status == 2 ? 'Completed' : ''); ?>

                                    <?php echo e($jobPost->status == 3 ? 'Rejected' : ''); ?>

                                </td>
                                <td>
                                    <ul class="job-dashboard-actions" >
                                        <li>
                                            <a href="<?php echo e(route('client.job-post.edit', $jobPost->id)); ?>" class="job-dashboard-action-edit">

                                                <i class="far fa-edit"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="job-dashboard-action-mark_filled text-danger">

                                                <i class="fas fa-arrow-circle-down"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" class="job-dashboard-action-delete" onclick="event.preventDefault();document.getElementById('gig<?php echo $jobPost->id; ?>').submit()">
                                                
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                            <form action="<?php echo e(route('client.job-post.destroy', $jobPost->id)); ?>" id="gig<?php echo e($jobPost->id); ?>" method="post" onsubmit="return confirm('Are you sure to delete this Gig')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>

                                            </form>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
















        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .job-dashboard-actions li {
            display: table-caption;
            /*padding: 2px 0;*/
        }
    </style>
    <!-- Datatables css -->
    <link href="<?php echo e(asset('/')); ?>frontend/assets/css/datatables.min.css" rel="stylesheet" type="text/css" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Datatables js -->



    <script type="text/javascript" src="<?php echo e(asset('/')); ?>frontend/assets/js/datatables.min.js"></script>
    <script>
        $(function () {
            $('#datatable-buttons').DataTable({
                // dom: 'Bfrtip',
                buttons: [
                    'copy', 'excel', 'pdf'
                ]
            });
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.auth-front.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/auth-front/client/post-job/index.blade.php ENDPATH**/ ?>