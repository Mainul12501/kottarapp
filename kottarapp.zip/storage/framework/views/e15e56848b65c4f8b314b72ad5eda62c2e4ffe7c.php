<?php $__env->startSection('title'); ?>
     Job Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Job post', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-capitalize float-start"> Job Post</h4>
                    <a href="<?php echo e(route('job-post.index')); ?>" class="btn btn-success float-end">
                        Manage
                    </a>
                </div>
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($group)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Category Name

                            </label>
                            <select name="" class="form-control select2" data-toggle="select2" id="">
                                <option value="">Select a category</option>
                                <option value="">Web Development</option>
                            </select>

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Sub Category Name

                            </label>
                            <select name="" class="form-control select2" data-toggle="select2" id="">
                                <option value="">Select a category</option>
                                <option value="">PHP</option>
                            </select>

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Required Skills

                            </label>
                            <select name="" class="form-control select2" data-toggle="select2" id="">
                                <option value="">Select a category</option>
                                <option value="">PHP</option>
                            </select>

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Title

                            </label>
                            <input type="text" class="form-control">

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Budget

                            </label>
                            <input type="text" class="form-control">

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Content

                            </label>
                            <textarea name="note" class="form-control" id="" cols="30" rows="5" placeholder="Note"></textarea>

                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Status

                            </label>
                            <div class="d-inline mt-3">
                                <input type="checkbox" name="status" id="switch1" checked data-switch="bool"/>
                                <label for="switch1" data-on-label="On" data-off-label="Off"></label>
                            </div>

                        </div>
                        <div class="d-grid">
                            <input type="submit" class="col-6 mx-auto btn btn-success" value="Create Skill Category">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/job-post/job-manage/create.blade.php ENDPATH**/ ?>