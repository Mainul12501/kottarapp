

<?php $__env->startSection('title'); ?>
    Create Role
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Roles', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="row">
                    <div class="col-md-8 mx-auto">
                        <div class="card mt-3">
                            <div class="card-header">
                                <h4 class="float-start">Create Role</h4>
                                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-success float-end">
                                    Manage

                                </a>
                            </div>
                            <div class="card-body">
                                <div>
                                    <form action="<?php echo e(isset($role) ? route('roles.update', $role->id) : route('roles.store')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php if(isset($role)): ?>
                                            <?php echo method_field('put'); ?>
                                        <?php endif; ?>
                                        <div class="mb-3">
                                            <label class="form-label">Role Title</label>
                                            <input type="text" class="form-control" name="title" value="<?php echo e(isset($role) ? $role->title : ''); ?>" data-provide="typeahead" id="the-basics" placeholder="Role Title">
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label">Role Permissions</label>
                                            <select name="permissions[]" class="select2 form-control select2-multiple" data-toggle="select2" multiple="multiple" data-placeholder="Set Permissions">
                                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($permission->id); ?>" <?php echo e(isset($role) && $role->permissions->contains($permission->id) ? 'selected' : ''); ?>><?php echo e($permission->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-3 float-end">
                                            <input type="submit" class="btn btn-success" data-provide="typeahead" id="" value="<?php echo e(isset($user) ? 'Update' : 'Create'); ?> Role">
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/user-role-permission-management/role/form.blade.php ENDPATH**/ ?>