<!doctype html>
<html lang="en">
<head>

    <!-- Basic Page Needs
    ================================================== -->
    <title>Knotter - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="icon" href="<?php echo e(asset('/')); ?>frontend/assets/images/fav.png" type="image/gif" sizes="64x64">

    <!-- CSS
    ================================================== -->
    <?php echo $__env->make('front.includes.assets.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<!-- Header 01
================================================== -->
<header class="header_01 <?php echo e(url()->current() !== url('/') ? 'header_inner' : ''); ?>">
    <div class="header_main">
        <?php echo $__env->make('front.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('home-page-header-only'); ?>
    </div>
</header>


<!-- End Header 02
================================================== -->



<!-- Main
================================================== -->
<main>
    <?php echo $__env->yieldContent('body'); ?>
</main>


<!-- Footer Container
================================================== -->
<?php echo $__env->make('front.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- End Footer Container
================================================== -->

<!-- Scripts
================================================== -->
<?php echo $__env->make('front.includes.assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/master.blade.php ENDPATH**/ ?>