<!doctype html>
<html lang="en">

<head>

    <!-- Basic Page Needs
    ================================================== -->
    <title>KnotterApp - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" href="<?php echo e(asset('/')); ?>frontend/assets/images/fav.png" type="image/gif" sizes="64x64">

    <!-- CSS
    ================================================== -->
    <?php echo $__env->make('front.includes.assets.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        let baseUrl = <?php echo json_encode(url('/')); ?> + '/';
    </script>
</head>
<body>

<!-- Header 01
================================================== -->
<header class="header_01 header_inner">
    <div class="header_main">
        <?php echo $__env->make('front.includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
</header>


<!-- End Header 02
================================================== -->



<!-- Main
================================================== -->
<main class="mt-5">
    <div class="job_container">
        <div class="container">
            <div class="row job_main">
                <?php echo $__env->make('front.auth-front.includes.side-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="job_main_right">
                    <?php echo $__env->yieldContent('body'); ?>
                </div>
            </div>
        </div>
    </div>
</main>


<!-- Footer Container
================================================== -->
<?php echo $__env->make('front.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- End Footer Container
================================================== -->

<!-- Scripts
================================================== -->
<?php echo $__env->make('front.includes.assets.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/front/auth-front/auth-master.blade.php ENDPATH**/ ?>