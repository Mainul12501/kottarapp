<?php $__env->startSection('title'); ?>
    Manage Job Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Job Post', 'child' => 'Manage'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-capitalize float-start">Manage Job Post</h4>
                            <a href="<?php echo e(route('job-post.create')); ?>" class="btn btn-success float-end">
                                
                                Create
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="">
                                <table id="dataTable" class="table table-striped dt-responsive table-responsive nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Skill Category</th>
                                        <th>Skill Sub Category</th>
                                        <th>Title</th>
                                        <th>Description</th>
                                        <th>Budget</th>
                                        <th>Required Skills</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>

                                            <td>
                                                Web Development
                                            </td>
                                            <td>PHP</td>
                                            <td>Create a web site</td>
                                            <td>minimum budget man</td>
                                            <td>150$</td>
                                            <td>HTML, CSS, LARAVEL</td>
                                            <td>
                                                Published
                                            </td>
                                            <td>
                                                    <a href="" class="btn btn-primary btn-sm mt-1 py-0 px-1">
                                                        <i class="dripicons-preview"></i>
                                                    </a>
                                                    <a href="" class="btn btn-primary btn-sm mt-1 py-0 px-1">
                                                        <i class="dripicons-document-edit f-s-11"></i>
                                                    </a>
                                                <form action="" method="post" style="display: inline-block" onsubmit="return confirm('Are you sure to delete this Admin?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm mt-1 py-0 px-1">
                                                        <i class="dripicons-trash f-s-11"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- Datatables css -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.bootstrap5.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Datatables js -->
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.bootstrap5.min.js"></script>


    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable({
                scrollX: true,
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/job-post/job-manage/index.blade.php ENDPATH**/ ?>