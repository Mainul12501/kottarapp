<?php $__env->startSection('title'); ?>
     Skill Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Skill Category', 'child' => 'Create'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-9 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h4 class="text-capitalize float-start"> Skill Category</h4>
                    <a href="<?php echo e(route('skills-category.index')); ?>" class="btn btn-success float-end">
                        Manage
                    </a>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(isset($skillCategory) ? route('skills-category.update', $skillCategory->id) : route('skills-category.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(isset($skillCategory)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                <span class="text-danger">*</span>
                                Category Name
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Write skill category name." data-bs-placement="right"></i>
                            </label>
                            <input type="text" class="form-control mb-1" name="category_name" value="<?php echo e(isset($skillCategory) ? $skillCategory->category_name : ''); ?>" placeholder="Group name" >
                            <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('category_name')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-2">
                            <label class="py-1" for="">
                                Status
                                <i class="dripicons-question" data-bs-toggle="tooltip" data-bs-title="Select publication status here." data-bs-placement="right"></i>
                            </label>
                            <div class="d-inline mt-3">
                                <input type="checkbox" name="status" id="switch1" <?php echo e((isset($skillCategory)&& $skillCategory->status == 0) ? '' : 'checked'); ?> data-switch="bool"/>
                                <label for="switch1" data-on-label="On" data-off-label="Off"></label>
                            </div>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger f-s-12"><?php echo e($errors->first('status')); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="d-grid">
                            <input type="submit" class="col-6 mx-auto btn btn-success" value="<?php echo e(isset($skillCategory) ? 'Update' : 'Create'); ?> Skill Category">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/job-post/skill-category/create.blade.php ENDPATH**/ ?>