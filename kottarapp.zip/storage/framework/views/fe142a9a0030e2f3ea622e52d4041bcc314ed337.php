<div class="leftside-menu">

    <!-- LOGO -->
    <a href="<?php echo e(route('dashboard')); ?>" class="logo text-center logo-light">
        <span class="logo-lg">
            <img src="<?php echo e(asset('/')); ?>frontend/assets/images/logo/Logo -orange.svg" alt="" height="16">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(asset('/')); ?>frontend/assets/images/logo/Logo Icon-Orange.svg" alt="" height="16">
        </span>
    </a>

    <!-- LOGO -->
    <a href="<?php echo e(route('dashboard')); ?>" class="logo text-center logo-dark">
        <span class="logo-lg">
            <img src="<?php echo e(asset('/')); ?>backend/assets/images/logo-dark.png" alt="" height="16">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(asset('/')); ?>backend/assets/images/logo_sm_dark.png" alt="" height="16">
        </span>
    </a>

    <div class="h-100" id="leftside-menu-container" data-simplebar>

        <!--- Sidemenu -->
        <ul class="side-nav">

            <li class="side-nav-title side-nav-item">Menu Options</li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Dashboard </span>
                </a>
            </li>

            <li class="side-nav-title side-nav-item">Only for admin</li>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#RolePermission" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Role Management </span>
                </a>
                <div class="collapse" id="RolePermission">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('permissions.index')); ?>">Permission</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('roles.index')); ?>">Role</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#skillManagement" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Skill Management </span>
                </a>
                <div class="collapse" id="skillManagement">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('skills-category.index')); ?>">Skills Category</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('skills-sub-category.index')); ?>">Skills Sub Category</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('skills.index')); ?>">Skills</a>
                        </li>

                    </ul>
                </div>
            </li>
            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#jobPostManagement" aria-expanded="false" aria-controls="sidebarDashboards" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Job Management </span>
                </a>
                <div class="collapse" id="jobPostManagement">
                    <ul class="side-nav-second-level">
                        <li>
                            <a href="<?php echo e(route('job-questions.index')); ?>">Job Questions</a>
                        </li>
                    </ul>
                </div>
            </li>
























            <li class="side-nav-item">
                <a href="javascript:void(0)" class="side-nav-link" onclick="event.preventDefault(); document.getElementById('logoutForm')">
                    <i class="uil-home-alt"></i>
                    <span> Logout </span>
                </a>
                <form action="<?php echo e(route('logout')); ?>" method="post" id="logOutForm">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<?php /**PATH G:\wamp64\www\kottarapp\resources\views/backend/includes/menu.blade.php ENDPATH**/ ?>