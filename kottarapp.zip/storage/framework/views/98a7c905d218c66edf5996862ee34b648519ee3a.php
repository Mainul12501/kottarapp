<?php $__env->startSection('home-page-header-only'); ?>
    <div class="header_btm">
        <h2>Register</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .only-form-box {
            max-width: 900px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="only-form-pages">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="only-form-box">
                        <div class="welcome-text text-center mb-5">
                            <h5 class="mb-0">Create an account!</h5>
                            <span>Already have an account? <a href="<?php echo e(route('front.login')); ?>">Log In!</a></span>
                        </div>







                        <form action="<?php echo e(route('front.register')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="com_class_form">
                                <div class="form-group user_type_cont">
                                    <label class="user_type" for="usertype-1">
                                        <input type="radio" <?php echo e(isset($_GET['type']) && $_GET['type'] == 0 ? 'checked' : ''); ?> name="usertype" id="usertype-1" value="0" >
                                        <span><i class="far fa-user"></i> Job Seeker</span>
                                    </label>
                                    <label class="user_type" for="usertype-2">
                                        <input type="radio" <?php echo e(isset($_GET['type']) && $_GET['type'] == 1 ? 'checked' : ''); ?> name="usertype" id="usertype-2" value="1" >
                                        <span><i class="fas fa-landmark"></i> Employer</span>
                                    </label>
                                </div>
                                <div class="freelancer-inputs">
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="first_name"  size="40" placeholder="First Name *">
                                        </div>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="last_name" size="40" placeholder="Last Name">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <input class="form-control" type="text" name="name" size="40" placeholder="Sure name ">
                                    </div>
                                </div>
                                <div class="client-inputs">
                                    <div class="form-group row">
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="company_name"  size="40" placeholder="Company Name *">
                                        </div>
                                        <div class="col-sm-6">
                                            <input class="form-control" type="text" name="trade_license_no" size="40" placeholder="Trade License Number *">
                                        </div>
                                        <div class="col-sm-12 mt-3">
                                            <input class="form-control" type="text" name="name" size="40" placeholder="User Name *">
                                        </div>
                                    </div>
                                </div>





























































































































































































































                                <div class="form-group">
                                    <input class="form-control" type="email" name="email" size="40" placeholder="Email address* ">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" type="password" name="password" placeholder=" Password * ">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" name="password_confirmation" placeholder="Re-enter Password * ">
                                </div>








































































































































































































































































                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" value="Register" >
                                </div>
                                <div class="form-group form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox"> Remember me
                                    </label>
                                </div>

                            </div>
                        </form>
                        <div class="social_login">
                            <p class="or_span"><span>or</span></p>
                            <button class="btn btn-facebook"><i class="fab fa-facebook-f"></i> Log In via Facebook</button>
                            <button class="btn btn-google"><i class="fab fa-google-plus-g"></i> Register via Google+</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            showHideInputFields();
        })
        $(document).on('click', '#usertype-1', function () {
            showHideInputFields();
        })
        $(document).on('click', '#usertype-2', function () {
            showHideInputFields();
        })
        function showHideInputFields() {
            var selectedUserType = $('input[name="usertype"]:checked').val();
            if (selectedUserType == 0)
            {
                $('.freelancer-inputs').removeClass('d-none');
                $('.client-inputs').addClass('d-none');
            } else if (selectedUserType == 1)
            {
                $('.client-inputs').removeClass('d-none');
                $('.freelancer-inputs').addClass('d-none');
            }

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/front/auth/register.blade.php ENDPATH**/ ?>