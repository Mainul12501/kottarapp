<?php $__env->startSection('title'); ?>
    Manage Job Post
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-title-section'); ?>
    <?php echo $__env->make('backend.includes.body-page-title-two',['parent'=>'Job Post', 'child' => 'Manage'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="text-capitalize float-start">Manage Job Post</h4>




                        </div>
                        <div class="card-body">
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.job-approve')->html();
} elseif ($_instance->childHasBeenRendered('vqr7fyi')) {
    $componentId = $_instance->getRenderedChildComponentId('vqr7fyi');
    $componentTag = $_instance->getRenderedChildComponentTagName('vqr7fyi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vqr7fyi');
} else {
    $response = \Livewire\Livewire::mount('admin.job-approve');
    $html = $response->html();
    $_instance->logRenderedChild('vqr7fyi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- Datatables css -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.bootstrap5.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Datatables js -->
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.bootstrap5.min.js"></script>


    <script>
        $(document).ready(function () {
            $('#dataTable').DataTable({
                scrollX: true,
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/backend/job-post/job-manage/index.blade.php ENDPATH**/ ?>