<?php $__env->startSection('title'); ?>
    post jobs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row job_section">
        <div class="col-sm-12">
            <div class="jm_headings">
                <h5>Post a job</h5>
                <a class="btn btn-primary mypbtn" href="compnay-profile-single.html">Company profile</a>
            </div>
            <div class="section-divider">
            </div>
            <form action="<?php echo e(isset($jobPost) ? route('client.job-post.update', $jobPost->id) : route('client.job-post.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($jobPost)): ?>
                    <?php echo method_field('put'); ?>
                <?php endif; ?>
                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  for="jobCategory">Job Categroy</label>
                                <select name="skill_category_id" class="form-control select2" required data-toggle="select2" data-placeholeder="Select a Job Category" id="jobCategory">
                                    <option <?php echo e(!isset($jobPost) ? 'selected' : ''); ?> disabled>Select a Job Category</option>
                                    <?php $__currentLoopData = $skillCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skillCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skillCategory->id); ?>" <?php echo e(isset($jobPost) && $jobPost->skill_category_id == $skillCategory->id ? 'selected' : ''); ?>><?php echo e($skillCategory->category_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  for="jobCategory">Job Sub Categroy</label>
                                <select name="skill_sub_category_id" class="form-control select2" required data-toggle="select2" data-placeholeder="Select a Job Category" id="jobSubCategory">
                                    <option <?php echo e(!isset($jobPost) ? 'selected' : ''); ?> disabled>Select a Job Category</option>
                                    <?php if(isset($jobPost)): ?>

                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label >Job Title</label>
                                <input type="text" name="project_title" class="form-control" placeholder="Write Job Title Here" />
                            </div>
                        </div>

                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Required Skills</label>
                                <select name="required_skills[]" class="form-control select2" multiple="multiple" data-toggle="select2" data-placeholeder="Select required skills" id="">
                                    <option  disabled>Select required skills</option>
                                    
                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($skill->id); ?>"><?php echo e($skill->skill_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Minimum Exiperience Level</label>
                                <select name="experience_level" class="form-control select2" required id="">
                                    <option value="0">Excited</option>
                                    <option value="1">Eager</option>
                                    <option value="2">Experienced</option>
                                    <option value="3">Expert</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group ">
                                <label  >Project Description</label>
                                <textarea class="form-control" name="project_description" id="editor"></textarea>
                            </div>
                        </div>

                    </div>
                </div>

                <div class="big_form_group">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Project Payment Type</label>
                                <select name="budget_type" class="form-control select2" data-toggle="select2">
                                    <option value="0">Fixed</option>
                                    <option value="1">Per Hour</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Budget</label>
                                <input type="number" name="budget" class="form-control" />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Hourly Rate</label>
                                <input type="number" name="budget_per_hour" class="form-control" />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Total Hour</label>
                                <input type="number" name="total_hour" class="form-control" />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label  >Freelancer Work Type</label>
                                <select name="freelancer_working_type" class="form-control select2" id="freelancerWorkType">
                                    <option value="0" selected>Remotely</option>
                                    <option value="1">Remotely on country</option>
                                    <option value="2">On Site</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 d-none" id="freelancerLocationCountry">
                            <div class="form-group">
                                <label >Freelancer Country</label>
                                <select name="preffered_freelancer_location_country" class="form-control select2" id="">
                                    <option value="UAE">UAE</option>
                                    <option value="USA">USA</option>
                                    <option value="Saudi Arabia">Saudi Arabia</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6 on-site-columns">
                            <div class="form-group">
                                <label >City</label>
                                <input type="text" class="form-control" name="job_location_city">
                            </div>
                        </div>
                        <div class="col-md-6 on-site-columns">
                            <div class="form-group">
                                <label >Starting Date</label>
                                <input type="text" class="form-control" name="job_starting_date">
                            </div>
                        </div>
                        <div class="col-md-6 on-site-columns">
                            <div class="form-group">
                                <label >Ending Date</label>
                                <input type="text" class="form-control" name="job_ending_time">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Project Duration</label>
                                <select name="estimate_project_duration_type" class="form-control select2" id="">
                                    <option value="1 Day or less">1 Day or less</option>
                                    <option value="2 days to 4 days">2 days to 4 days</option>
                                    <option value="Less than a week">Less than a week</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Want to ask a question?</label>
                                <select name="job_questions[]" multiple class="form-control select2" id="">
                                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($question->id); ?>"><?php echo e($question->question); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label >Upload Files</label>
                                <input type="file" name="files[]" multiple />
                            </div>
                        </div>
                    </div>
                </div>


























                <div class="form-group row">
                    <div  class="col-md-9 ">
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($jobPost) ? 'Update' : 'Submit'); ?></button>
                    </div>
                </div>

            </form>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .on-site-columns {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).on('change', '#jobCategory', function () {
            var categoryId = $(this).val();
            $.ajax({
                url: baseUrl+'get-skill-sub-categories/'+categoryId,
                method: "GET",
                dataType: "JSON",
                success: function (data) {
                    console.log(data);
                    var option = '';
                    $.each(data, function (key, item) {
                        option += '<option value="'+item.id+'">'+item.sub_category_name+'</option>';
                    })
                    $('#jobSubCategory').empty().append(option);
                },
                error: function (error)
                {
                    toastr.error('Someting went wrong. please try again.');
                }
            })
        })
    </script>

    <script>
        CKEDITOR.replace( 'project_description' );
    </script>

    <script>
        $(document).on('change', '#freelancerWorkType', function () {
            var selectedWorkType = $(this).val();
            if(selectedWorkType == 1)
            {
                $('#freelancerLocationCountry').removeClass('d-none');
            } else {
                $('#freelancerLocationCountry').addClass('d-none');
            }
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.auth-front.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/front/auth-front/client/post-job/create.blade.php ENDPATH**/ ?>