<?php $__env->startSection('title'); ?>
    Browse Gigs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="jm_headings">
        <h5 class="text-center">Browse Gigs</h5>
    </div>

    <div class="row full_width featured_box_outer">
        <?php $__currentLoopData = $gigs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('freelancer.gig-details',['slug' => $gig->job_post_slug])); ?>">
                <div class="col-sm-12">
                    <div class="featured_box ">
                        <div class="fb_image">
                            <img alt="brand logo" src="<?php echo e(asset($gig->user->userDetails->profile_image)); ?>">
                        </div>
                        <div class="fb_content">
                            <h4><?php echo e($gig->project_title); ?></h4>
                            <ul>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-landmark"></i>
                                        Magna Aliqua
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="fas fa-map-marker-alt"></i>
                                        New York
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="far fa-clock"></i>
                                        <?php echo e($gig->created_at->diffForHumans()); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="fb_action">
                            
                            
                            <span class="font-weight-bold f-s-30">$<?php echo e($gig->budget); ?></span>
                        </div>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.auth-front.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/auth-front/freelancer/jobs/browse/jobs.blade.php ENDPATH**/ ?>