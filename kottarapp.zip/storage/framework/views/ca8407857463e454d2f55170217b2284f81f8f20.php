


<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <?php if(isset($parent)): ?>
                        <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($parent); ?></a></li>
                    <?php endif; ?>
                    <?php if(isset($child)): ?>
                        <li class="breadcrumb-item active"><?php echo e($child); ?></li>
                    <?php endif; ?>
                </ol>
            </div>
            <h4 class="page-title"><?php echo e(isset($parent) ? $parent : ''); ?></h4>
        </div>
    </div>
</div>
<?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/includes/body-page-title-two.blade.php ENDPATH**/ ?>