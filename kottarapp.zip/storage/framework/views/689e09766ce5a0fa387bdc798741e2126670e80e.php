
<!-- bundle -->
<script src="<?php echo e(asset('/')); ?>backend/assets/js/vendor.min.js"></script>
<script src="<?php echo e(asset('/')); ?>backend/assets/js/app.min.js"></script>
<script src="<?php echo e(asset('/')); ?>backend/assets/js/vendor/toastrjs.min.js"></script>
<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    let baseUrl = <?php echo json_encode(url('/')); ?>+'/';
</script>

<?php if(Session::has('success')): ?>
    <script>
        $(document).ready(function () {
            toastr.success("<?php echo e(Session::get('success')); ?>");
        });
    </script>
    <?php echo e(Session::forget('success')); ?>

<?php endif; ?>
<?php if(Session::has('error')): ?>
    <script>
        $(document).ready(function () {
            toastr.error("<?php echo e(Session::get('error')); ?>");
        });
    </script>
    <?php echo e(Session::forget('error')); ?>

<?php endif; ?>


<?php echo $__env->yieldContent('script'); ?>
<?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/backend/includes/assets/js.blade.php ENDPATH**/ ?>