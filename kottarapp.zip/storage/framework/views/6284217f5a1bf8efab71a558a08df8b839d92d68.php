<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700&amp;display=swap&amp;subset=latin-ext" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/all.min.css">
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/aos.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/bootstrap.min.css">
<link href="<?php echo e(asset('/')); ?>frontend/assets/css/select2.min.css" rel="stylesheet" />

<link href="<?php echo e(asset('/')); ?>frontend/assets/css/owl.carousel.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css" />
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/style.css">
<link rel="stylesheet" href="<?php echo e(asset('/')); ?>frontend/assets/css/color-1.css">
<?php echo $__env->yieldContent('style'); ?>

<?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/front/includes/assets/css.blade.php ENDPATH**/ ?>