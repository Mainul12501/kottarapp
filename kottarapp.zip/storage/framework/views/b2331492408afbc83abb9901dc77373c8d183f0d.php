<?php $__env->startSection('home-page-header-only'); ?>
    <div class="header_btm">
        <h2>Register</h2>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .only-form-box {
            max-width: 500px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="only-form-pages">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="only-form-box">
                        <div class="welcome-text text-center mb-5">
                            <h5 class="mb-0">Create an account!</h5>
                            <span>Already have an account? <a href="<?php echo e(route('login')); ?>">Log In!</a></span>
                        </div>
                        <form action="<?php echo e(route('register')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="com_class_form">
                                <div class="form-group">
                                    <input class="form-control" type="text" name="first_name" size="40" placeholder="Name">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="text" name="name" size="40" placeholder="Username ">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" type="email" name="email" size="40" placeholder="Email address* ">
                                </div>

                                <div class="form-group">
                                    <input class="form-control" type="password" name="password" placeholder=" Password * ">
                                </div>
                                <div class="form-group">
                                    <input class="form-control" type="password" name="password_confirmation" placeholder="Re-enter Password * ">
                                </div>

                                <div class="form-group">
                                    <input class="btn btn-primary" type="submit" value="Register" >
                                </div>
                                <div class="form-group form-check">
                                    <label class="form-check-label">
                                        <input class="form-check-input" type="checkbox"> Remember me
                                    </label>
                                </div>

                            </div>
                        </form>
                        <div class="social_login">
                            <p class="or_span"><span>or</span></p>
                            <button class="btn btn-facebook"><i class="fab fa-facebook-f"></i> Log In via Facebook</button>
                            <button class="btn btn-google"><i class="fab fa-google-plus-g"></i> Register via Google+</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Xampp-php-8.1\htdocs\kottarapp\resources\views/front/auth/admin-register.blade.php ENDPATH**/ ?>