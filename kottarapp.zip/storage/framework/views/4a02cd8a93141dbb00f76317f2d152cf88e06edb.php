<?php $__env->startSection('title'); ?>
    <?php echo e($gig->job_post_slug); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('home-page-header-only'); ?>
    <div class="header_btm header_job_single">
        <div class="header_job_single_inner container">
            <div class="poster_company">

                <img alt="brand logo" src="<?php echo e(asset($gig->user->userDetails->profile_image)); ?>">
            </div>
            <div class="poster_details">
                <h2><?php echo e($gig->project_title); ?> <span class="varified"><i class="fas fa-check"></i>Verified</span></h2>

                <ul>






                    <li>
                        <a href="#">
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo e(!empty($gig->user->userDetails->country) ? $gig->user->userDetails->country : 'UAE'); ?>

                        </a>
                    </li>
                    <li>
                        <a href="#">
                            <i class="far fa-clock"></i>
                            <?php echo e($gig->created_at->diffForHumans()); ?>

                        </a>
                    </li>
                </ul>
            </div>
            <div class="poster_action">


                <a class="btn btn-third <?php $__currentLoopData = $gig->applyJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applyJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($applyJob->freelancer_user_id == auth()->id()): ?> disabled <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>" href="#" onclick="event.preventDefault(); document.getElementById('applyGig').submit()">Apply Now</a>
                <form action="<?php echo e(route('freelancer.apply-gig', ['slug' => $gig->job_post_slug])); ?>" method="post" style="display: none" id="applyGig">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="single_job">
        <div class="container">
            <div class="row">
                <div class="col-md-9">
                    <div class="row ">
                        <div class="col-md-12 single_job_main">
                            <h2>Job Description</h2>
                            <?php echo $gig->project_description; ?>

                        </div>





















































































                    </div>
                </div>
                <div class="col-md-3 ">
                    <div class="single-job-sidebar">
                        <div class="sjs_box">
                            <h3>Job Summary</h3>
                            <ul class="single-job-sidebar-features">
                                <li>
                                    <i class="fas fa-map-marker-alt"></i>
                                    <h6>Location</h6>
                                    <p><?php echo e($gig->user->userDetails->country); ?></p>
                                </li>





                                <li>
                                    <i class="fas fa-money-bill-alt"></i>
                                    <h6>Budget</h6>
                                    <p>$<?php echo e($gig->budget); ?></p>
                                </li>
                                <li>
                                    <i class="far fa-clock"></i>
                                    <h6>Date Posted</h6>
                                    <p><?php echo e($gig->created_at->format('d M Y')); ?></p>
                                </li>
                            </ul>
                        </div>
                        <div class="sjs_box">
                            <h3>Tags</h3>
                            <ul class="tags">
                                <?php $__currentLoopData = $gig->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($skill->skill_name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>





                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\wamp64\www\kottarapp\resources\views/front/auth-front/freelancer/jobs/browse/details.blade.php ENDPATH**/ ?>