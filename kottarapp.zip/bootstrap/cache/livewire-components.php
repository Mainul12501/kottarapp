<?php return array (
  'admin.job-approve' => 'App\\Http\\Livewire\\Admin\\JobApprove',
);